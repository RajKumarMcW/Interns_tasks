import numpy as np
from collections import Counter

class decision_Tree:

    def __init__(self):
        self.no_of_unique = 11
        self.counter = 0
        self.min_samples = 100
        self.max_depth = 100

    def __str__(self):
        return "DecisionTree"

    def type_of_cols(self, data):
        col_type = []
        for col in data.columns[:-1]:
            no_of_col_unique = data[col].nunique()
            col_type.append("categorical" if data[col].dtypes == object or no_of_col_unique <= self.no_of_unique else "continuous")
        return col_type

    def get_splits(self, data):
        splits = {}
        feature_type = self.type_of_cols(data)
        for column_index in range(data.shape[1]-1):
            values = data.iloc[:, column_index]
            unique_values = np.unique(values)
            type_of_feature = feature_type[column_index]

            if type_of_feature == "continuous":
                splits[column_index] = [(unique_values[i] + unique_values[i-1]) / 2 for i in range(1, len(unique_values))]

            elif len(unique_values) > 1:
                splits[column_index] = unique_values

        return splits

    def split_data(self, data, column, value):
        split_values = data.iloc[:, column]
        type_of_feature = self.type_of_cols(data)[column]

        if type_of_feature == "continuous":
            left = data[split_values <= value]
            right = data[split_values > value]

        else:
            left = data[split_values == value]
            right = data[split_values != value]

        return left, right

    def entropy(self, data):
        prob = list(dict(data.iloc[:, -1].value_counts(normalize=True)).values())
        entropy = -np.sum(prob * np.log2(prob))
        return entropy

    def entropy_data(self, left, right):
        n = len(left) + len(right)
        p_left = len(left) / n
        p_right = len(right) / n
        entropy_ = p_left * self.entropy(left) + p_right * self.entropy(right)
        return entropy_

    def best_split(self, data, splits):
        entropy = 99999
        for col in splits:
            for val in splits[col]:
                left, right = self.split_data(data, column=col, value=val)
                current_entropy = self.entropy_data(left, right)
                if current_entropy <= entropy:
                    entropy = current_entropy
                    best_column = col
                    best_split = val

        return best_column, best_split

    def _tree_builder(self, df):
        column = df.columns
        feature_type = self.type_of_cols(df)
        data = df

        if (df.iloc[:, -1].nunique() == 1) or (len(data) < self.min_samples) or (self.counter == self.max_depth):
            classes = Counter(df.iloc[:, -1]).most_common(1)[0][0]
            return classes

        else:
            self.counter += 1
            splits = self.get_splits(data)
            split_column, split_value = self.best_split(data, splits)
            left, right = self.split_data(data, split_column, split_value)

            feature_name = column[split_column]
            type_of_feature = feature_type[split_column]

            if type_of_feature == "continuous":
                question = "{} <= {}".format(feature_name, split_value)
            else:
                question = "{} = {}".format(feature_name, split_value)

            mytree = {question: []}

            ans_yes = self._tree_builder(left)
            ans_no = self._tree_builder(right)

            if ans_yes == ans_no:
                mytree = ans_yes
            else:
                mytree[question].append(ans_yes)
                mytree[question].append(ans_no)
            return mytree

    def cfit(self, X, y):
        X["output"] = y
        self.tree = self._tree_builder(X)
        X.drop("output", axis=1, inplace=True)
        return self.tree

    def _predict(self, dx, tree):
        root_node = list(tree.keys())[0]
        column, operator, split = root_node.split(" ")

        if operator == "<=":
            result = tree[root_node][0] if dx[column] <= float(split) else tree[root_node][1]

        else:
            result = tree[root_node][0] if str(dx[column]) == split else tree[root_node][1]

        return result if type(result) != dict else self._predict(dx, result)

    def cpredict(self, X_test):
        s = [self._predict(X_test.iloc[i], self.tree) for i in range(X_test.shape[0])]
        return s